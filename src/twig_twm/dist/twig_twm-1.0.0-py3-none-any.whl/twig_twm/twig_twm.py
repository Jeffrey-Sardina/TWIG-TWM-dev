def do_job():
    print('Hey, it works!')
    print('I am currently refactoring the code, try again soon!')
